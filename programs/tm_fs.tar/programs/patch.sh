#!/bin/sh
# Fast Script Patcher
# Powered by Ayaka7452
# * termod mod *


# defines
tmodid="fs"
tmoddir=`dirname $0`


if [ -f $tmoddir/patched ]; then
 termod inject fs fs bin 1
 rm $tmoddir/patched
 echo "removed core exec from termux"
 exit
fi


# patches pyhub to termux app
termod inject fs fs bin 0
echo "deployed core exec to termux"

echo "" > $tmoddir/patched


# eos
